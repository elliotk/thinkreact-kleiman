# scikit-learn
import sklearn
print('sklearn: %s' % sklearn.__version__)