# create one array
from numpy import ones
a = ones([5])
print(a)