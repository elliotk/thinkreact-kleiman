Long Short-Term Memory Networks With Python
===========================================

README
------

Welcome to Long Short-Term Memory Networks With Python!

Your package contains:

1. README (this file)
	README.txt
2. The Ebook:
	long_short_term_memory_networks_with_python.pdf
3. Code Recipes:
	code/

The code directory provides access to all of the data and code examples used in the book.

Any questions at all, contact me direction via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.
